import java.util.*;

public class main {
    public static void main(String[] args) {
        poker poker = new poker();

        Date dateStart = new Date();
        long start = dateStart.getTime();

        deck mainDeck = new deck();

        int[] results =  new int[10];
        Arrays.fill(results, 0);

        int iterations = 13378456;

        for (int iteration = 0; iteration < iterations; iteration++) {
            mainDeck.shuffle();
            int nextCardIndex = 0;

            player player = new player();
            for (int i = 0; i < 2; i++) {
                player.hand[i] = mainDeck.deck[nextCardIndex];
                nextCardIndex++;
            }
            card[] house = new card[5];
            for (int i = 0; i < 5; i++) {
                house[i] = mainDeck.deck[nextCardIndex];
                nextCardIndex++;
            }

            poker.cardAnalysisEfficient(player,house);
            results[player.handScore]++;
        }
        Date dateEnd = new Date();
        long end = dateEnd.getTime();
        System.out.println("Royal flush %: " +      ( (double) results[0] / (iterations/100) ) + ", Real probability is: 0.0032%");
        System.out.println("Straight flush %: " +   ( (double) results[1] / (iterations/100) ) + ", Real probability is: 0.0279%");
        System.out.println("Four of a kind %: " +   ( (double) results[2] / (iterations/100) ) + ", Real probability is: 0.168%");
        System.out.println("Full house %: " +       ( (double) results[3] / (iterations/100) ) + ", Real probability is: 2.60%");
        System.out.println("Flush %: " +            ( (double) results[4] / (iterations/100) ) + ", Real probability is: 3.03%");
        System.out.println("Straight %: " +         ( (double) results[5] / (iterations/100) ) + ", Real probability is: 4.62%");
        System.out.println("Three of a kind %: " +  ( (double) results[6] / (iterations/100) ) + ", Real probability is: 4.83%");
        System.out.println("Two pair %: " +         ( (double) results[7] / (iterations/100) ) + ", Real probability is: 23.5%");
        System.out.println("Pair %: " +             ( (double) results[8] / (iterations/100) ) + ", Real probability is: 43.8%");
        System.out.println("High card %: " +        ( (double) results[9] / (iterations/100) ) + ", Real probability is: 17.4%");
        System.out.println("This took " + (end-start) + " milliseconds or " + ((end-start)/1000) + " seconds");
        System.out.println(poker.printNum());
    }
}
